var tl=gsap.timeline()
tl.to(".navbar",{
   opacity:1,
    x:10,
    duration:2,
    delay:1,
    yoyo:true,
    stagger:3,
})

